chrome-decrypter
================
Python script to decrypt saved Chrome usernames and passwords on windows
